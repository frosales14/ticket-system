/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./src/**/*.{html,ts}'],
  theme: {
    extend: {
      backgroundImage: {
        'auth-bg': "url('/assets/img/auth/authbg.webp')"
      }
    },
  },
  plugins: [],
}

